73 43 b
10 71 y
76 78 y
43 27 y
24 34 y
8 74 y
done 1          ok
74 43 b
8 71 y
76 76 y
43 29 y
22 34 y
6 74 y
done 2          ok
75 43 b
6 71 y
76 74 y
43 31 y
20 34 y
4 74 y
done 3          ok
74 43 b
4 71 y
76 72 y
43 33 y
18 34 y
2 74 y 
done 4          ok
74 42 b
2 71 y
76 70 y
43 35 y
16 34 y
0 74 y
done 5          ok
74 41 b
0 71 y
76 68 y
43 37 y
14 34 y
78 74 y
done 6          ok
74 40 b
78 71 y
76 66 y
43 39 y
12 34 y
76 74 y
done 7          ok
74 39 b
76 71 y
76 64 y
43 41 y
12 36 y
74 74 y
done 8          ok
74 38 b         ok
74 71 y         ok
76 62 y         ok
43 43 y         ok
12 38 c         -- change
74 72 y         ok
done 9
75 38 b        
72 71 y         
76 60 y         
43 45 y         
10 38 c         
74 70 y
done 10
76 38 b
70 71 y
76 58 y
43 47 y
12 38 c
74 68 y
done 11
